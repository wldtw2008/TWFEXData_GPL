This directory contains a very simple C console application
that uses the LITEUNZIP.DLL to unzip the contents of a sample
ZIP archive (test.zip) into a memory buffer. The test.zip
archive was made with ZipMemoryRaw, so there is no ZIP header
on the zip archive. Because of this, we also unzip it in raw
mode using UnzipOpenFileRaw().

For Linux, run the "makefile" with GNU's make. For Windows, open
the UnzipMemRaw.mdp Visual Studio Workspace.