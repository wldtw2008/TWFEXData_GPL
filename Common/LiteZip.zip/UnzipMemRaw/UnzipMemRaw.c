#ifdef WIN32
#include <windows.h>
#include <tchar.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <errno.h>
#include <unistd.h>
typedef void * HMODULE;
typedef char TCHAR;
#define _T(a) (a)
#endif

// Include LiteUnzip.h for unzipping a ZIP archive
#include "../LiteUnzip.h"





// Where we store the pointers to LiteUnzip.dll's functions that we call
UnzipOpenFileRawPtr		*lpUnzipOpenFileRaw;
UnzipGetItemPtr			*lpUnzipGetItem;
UnzipItemToBufferPtr	*lpUnzipItemToBuffer;
UnzipClosePtr			*lpUnzipClose;
UnzipFormatMessagePtr	*lpUnzipFormatMessage;






/************************** main() *************************
 * Program entry point.
 */

int main()
{
	HMODULE		unzipDll;
	HUNZIP		huz;
	DWORD		result;

#ifdef WIN32
	// Open the LiteUnzip.DLL. Note: If LiteUnzip.dll is not placed in a path that can be found
	// by this app, then LoadLibrary will fail. So, either copy LiteUnzip.dll to the same
	// directory as this EXE, or to some directory that Windows is set to search.
	if ((unzipDll = (HMODULE)LoadLibrary(_T("../LiteUnzip/Debug/LiteUnzip.dll"))))
	{
		// Get the addresses of 5 functions in LiteUnzip.dll -- UnzipOpenFile(), UnzipGetItem()
		// UnzipItemToFile(), UnzipClose(), and UnzipFormatMessage.
		lpUnzipOpenFileRaw = (UnzipOpenFileRawPtr *)GetProcAddress(unzipDll, UNZIPOPENFILERAWNAME);
		lpUnzipGetItem = (UnzipGetItemPtr *)GetProcAddress(unzipDll, UNZIPGETITEMNAME);
		lpUnzipItemToBuffer = (UnzipItemToBufferPtr *)GetProcAddress(unzipDll, UNZIPITEMTOBUFFERNAME);
		lpUnzipClose = (UnzipClosePtr *)GetProcAddress(unzipDll, UNZIPCLOSENAME);
		lpUnzipFormatMessage = (UnzipFormatMessagePtr *)GetProcAddress(unzipDll, UNZIPFORMATMESSAGENAME);
#else
	if ((unzipDll = (HMODULE)dlopen("../LiteUnzip/libliteunzip.so", RTLD_LAZY)))
	{
		// Get the addresses of 5 functions in LiteUnzip.dll -- UnzipOpenFile(), UnzipGetItem()
		// UnzipItemToFile(), UnzipClose(), and UnzipFormatMessage.
		lpUnzipOpenFileRaw = (UnzipOpenFileRawPtr *)dlsym(unzipDll, UNZIPOPENFILERAWNAME);
		lpUnzipGetItem = (UnzipGetItemPtr *)dlsym(unzipDll, UNZIPGETITEMNAME);
		lpUnzipItemToBuffer = (UnzipItemToBufferPtr *)dlsym(unzipDll, UNZIPITEMTOBUFFERNAME);
		lpUnzipClose = (UnzipClosePtr *)dlsym(unzipDll, UNZIPCLOSENAME);
		lpUnzipFormatMessage = (UnzipFormatMessagePtr *)dlsym(unzipDll, UNZIPFORMATMESSAGENAME);
#endif
		// Open a ZIP archive on disk named "test.zip".
		if (!(result = lpUnzipOpenFileRaw(&huz, _T("test.zip"), 0)))
		{
			ZIPENTRY		ze;
			unsigned char	*buffer;

			// Because the zip archive was created "raw" (ie, without any ZIP
			// header), then we MUST know what the original size is, as well as
			// the compressed size. We put these two values in the ZIPENTRY before
			// we call one of the UnzipItemXXX functions
			ze.CompressedSize = 67;
			ze.UncompressedSize = 69;

			// Allocate a memory buffer to decompress the item
#ifdef WIN32
			if (!(buffer = GlobalAlloc(GMEM_FIXED, ze.UncompressedSize)))
#else
			if (!(buffer = malloc(ze.UncompressedSize)))
#endif
			{
#ifdef WIN32
				TCHAR msg[160];

				msg[0] = 0;
				FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &msg[0], 160, 0);
				MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
				printf("ERROR: %s\n", strerror(errno));
#endif
			}

			else
			{
				// Decompress the item into our buffer
				if ((result = lpUnzipItemToBuffer(huz, buffer, ze.UncompressedSize, &ze)))
				{
#ifdef WIN32
					GlobalFree(buffer);
#else
					free(buffer);
#endif
					lpUnzipClose(huz);
					goto bad;
				}

#ifdef WIN32
				// Here we would do something with the contents of buffer. It contains
				// ze.UncompressedSize bytes. We'll just display it to the console.
				WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), buffer, ze.UncompressedSize, &ze.CompressedSize, 0);

				// We have no further use for the buffer, so we must free it.
				GlobalFree(buffer);
#else
				fwrite(buffer, ze.UncompressedSize, 1, stdout);
				free(buffer);
#endif
			}

			// Done unzipping files, so close the ZIP archive.
			lpUnzipClose(huz);
		}
		else
		{
			TCHAR	msg[100];

bad:		lpUnzipFormatMessage(result, msg, sizeof(msg));
#ifdef WIN32
			MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
			printf("ERROR: %s\n", &msg[0]);
#endif
		}

		// Free the LiteUnzip.DLL
#ifdef WIN32
		FreeLibrary(unzipDll);
#else
		dlclose(unzipDll);
#endif
	}
	else
	{
#ifdef WIN32
		TCHAR msg[160];

		msg[0] = 0;
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &msg[0], 160, 0);
		MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
		printf("ERROR: %s\n", dlerror());
#endif
	}

	return(0);
}
