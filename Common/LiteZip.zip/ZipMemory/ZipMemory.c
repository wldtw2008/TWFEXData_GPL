#ifdef WIN32
#include <windows.h>
#include <tchar.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
typedef void * HMODULE;
typedef char TCHAR;
#define _T(a) (a)
#define lstrlen(a) strlen(a)
#endif

// Include LiteZip.h for creating a ZIP archive
#include "../LiteZip.h"





// Where we store the pointers to LiteZip.dll's functions that we call
ZipCreateBufferPtr		*lpZipCreateBuffer;
ZipAddBufferPtr			*lpZipAddBuffer;
ZipGetMemoryPtr			*lpZipGetMemory;
ZipClosePtr				*lpZipClose;
ZipFormatMessagePtr		*lpZipFormatMessage;

// Here is some data in memory which we'll compress into our zip file
const TCHAR Data1[] =	_T("This is some data.\r\n\r\nThis is line two.\r\n");
const TCHAR Data2[] =	_T("This is a test of LiteZip.dll.\r\n\r\nHopefully this worked!\r\n");


#ifdef WIN32
/*********************** show_errmsg() **********************
 * Displays a messagebox for the passed OS error number.
 */

void show_errmsg(void)
{
	TCHAR buffer[160];

	buffer[0] = 0;
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 160, 0);
	MessageBox(0, &buffer[0], _T("Error"), MB_OK);
}
#endif



/************************** main() *************************
 * Program entry point.
 */

int main()
{
	HMODULE		zipDll;
	HZIP		hz;
	DWORD		result;

#ifdef WIN32
	// Open the LiteZip.DLL. Note: If LiteZip.dll is not placed in a path that can be found
	// by this app, then LoadLibrary will fail. So, either copy LiteZip.dll to the same
	// directory as this EXE, or to some directory that Windows is set to search.
	if ((zipDll = (HMODULE)LoadLibrary(_T("../LiteZip.dll"))))
	{
		// Get the addresses of 5 functions in LiteZip.dll -- ZipCreateBuffer(), ZipAddBuffer()
		// ZipGetMemory(), ZipClose, and ZipFormatMessage
		lpZipCreateBuffer = (ZipCreateBufferPtr *)GetProcAddress(zipDll, ZIPCREATEBUFFERNAME);
		lpZipAddBuffer = (ZipAddBufferPtr *)GetProcAddress(zipDll, ZIPADDBUFFERNAME);
		lpZipGetMemory = (ZipGetMemoryPtr *)GetProcAddress(zipDll, ZIPGETMEMORYNAME);
		lpZipFormatMessage = (ZipFormatMessagePtr *)GetProcAddress(zipDll, ZIPFORMATMESSAGENAME);
		lpZipClose = (ZipClosePtr *)GetProcAddress(zipDll, ZIPCLOSENAME);
#else
	if ((zipDll = dlopen("../LiteZip/liblitezip.so", RTLD_LAZY)))
	{
		lpZipCreateBuffer = (ZipCreateBufferPtr *)dlsym(zipDll, ZIPCREATEBUFFERNAME);
		lpZipAddBuffer = (ZipAddBufferPtr *)dlsym(zipDll, ZIPADDBUFFERNAME);
		lpZipGetMemory = (ZipGetMemoryPtr *)dlsym(zipDll, ZIPGETMEMORYNAME);
		lpZipFormatMessage = (ZipFormatMessagePtr *)dlsym(zipDll, ZIPFORMATMESSAGENAME);
		lpZipClose = (ZipClosePtr *)dlsym(zipDll, ZIPCLOSENAME);
#endif
		// Create a ZIP archive in a memory buffer. Let LiteZip.dll allocate growable memory
		// from the memory pool. We'll set an upper limit of 100,000 bytes on this growable
		// memory. NOTE: This limit is not applicable to Linux
		if (!(result = lpZipCreateBuffer(&hz, 0, 100000, 0)))
		{
			unsigned char	*buffer;
			DWORD			len;
			HANDLE			base;

			// Add the contents of the Data1[] memory buffer to the ZIP, and give it the
			// name "data1.txt".
			if ((result = lpZipAddBuffer(hz, _T("data1.txt"), &Data1[0], lstrlen(&Data1[0])))) goto bad2;

			// Add the contents of the Data2[] memory buffer to the ZIP, and give it the
			// name "data2.txt".
			if ((result = lpZipAddBuffer(hz, _T("data2.txt"), &Data2[0], lstrlen(&Data2[0]))))
			{
bad2:			lpZipClose(hz);
				goto bad;
			}

			// Here we could call ZipAddFile to add disk files to the ZIP archive. We could
			// also call ZipAddBuffer to add the contents of another memory buffer as a "file"
			// inside the zip. Or, we could call ZipAddHandle to add the contents of some open
			// file or pipe.

			// We're done adding files to our ZIP in memory, so let's get a pointer to that
			// memory, and the final size of it. NOTE: We tell LiteZip.dll to give us the
			// memory, and we'll free it when we're done.
			if ((result = lpZipGetMemory(hz, (void **)&buffer, &len, &base))) goto bad;

			// Let's write out the zip memory-buffer to a disk file named "test.zip"
#ifdef WIN32
			{
			HANDLE	handle;
			DWORD	written;

			handle = CreateFile(_T("test.zip"), GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
			if (handle == INVALID_HANDLE_VALUE) show_errmsg();
			else
			{
				if (!WriteFile(handle, buffer, len, &written, 0)) show_errmsg();

				CloseHandle(handle);
			}
			}

			// Free the memory now that we're done with it.
			UnmapViewOfFile(buffer);
			CloseHandle(base);
#else
			{
			int	handle;

			if ((handle = open("test.zip", O_RDWR|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR)) == -1)
				printf("ERROR: %s\n", strerror(errno));
			else
			{
				if (write(handle, base, len) != len)
					printf("ERROR: %s\n", strerror(errno));
				close(handle);
			}
			}

			// Free the memory now that we're done with it.
			free(base);
#endif
		}
		else
		{
			TCHAR	msg[100];

bad:		lpZipFormatMessage(result, msg, sizeof(msg));
#ifdef WIN32
			MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
			printf("ERROR: %s\n", &msg[0]);
#endif
		}

		// Free the LiteZip.DLL
#ifdef WIN32
		FreeLibrary(zipDll);
#else
		dlclose(zipDll);
#endif
	}
	else
	{
#ifdef WIN32
		show_errmsg();
#else
		printf("ERROR: %s\n", dlerror());
#endif
	}

	return(0);
}
