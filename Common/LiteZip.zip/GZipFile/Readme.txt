This directory contains a very simple C console application
that uses the LITEZIP.DLL to zip a sample jpeg file (test.jpg)
into a GZIP archive.

For Linux, run the "makefile" with GNU's make. For Windows, open
the GZipFile.mdp Visual Studio Workspace.