This directory contains a very simple C console application
that uses the LITEZIP.DLL to zip a directory and its
subdirectories.

For Linux, run the "makefile" with GNU's make. For Windows, open
the ZipDir.mdp Visual Studio Workspace.