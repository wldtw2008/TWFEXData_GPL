This directory contains a very simple C console application
that uses the LITEUNZIP.DLL to unzip the contents of a sample
ZIP archive (test.zip) into a memory buffer.

For Linux, run the "makefile" with GNU's make. For Windows, open
the UnzipMem.mdp Visual Studio Workspace.