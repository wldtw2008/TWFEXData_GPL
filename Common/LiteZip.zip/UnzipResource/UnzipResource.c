#include <windows.h>
#include <tchar.h>
#include "../LiteUnzip.h"





// Where we store the pointers to LiteUnzip.dll's functions that we call
UnzipOpenBufferPtr		*lpUnzipOpenBuffer;
UnzipGetItemPtr			*lpUnzipGetItem;
#ifdef UNZIPPING_TO_MEMORY
UnzipItemToBufferPtr	*lpUnzipItemToBuffer;
#else
UnzipItemToFilePtr		*lpUnzipItemToFile;
#endif
UnzipClosePtr			*lpUnzipClose;
UnzipFormatMessagePtr	*lpUnzipFormatMessage;





/*********************** show_errmsg() **********************
 * Displays a messagebox for the passed OS error number.
 */

void show_errmsg(void)
{
	TCHAR buffer[160];

	buffer[0] = 0;
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 160, 0);
	MessageBox(0, &buffer[0], _T("Error"), MB_OK);
}





/************************** main() *************************
 * Program entry point.
 */

int main()
{
	HMODULE		unzipDll;
	HUNZIP		huz;
	DWORD		result;

	// Open the LiteUnzip.DLL. Note: If LiteUnzip.dll is not placed in a path that can be found
	// by this app, then LoadLibrary will fail. So, either copy LiteUnzip.dll to the same
	// directory as this EXE, or to some directory that Windows is set to search.
	if ((unzipDll = (HMODULE)LoadLibrary(_T("../LiteUnzip.dll"))))
	{
		// Get the addresses of 5 functions in LiteUnzip.dll -- UnzipOpenBuffer(), UnzipGetItem()
		// UnzipItemToBuffer() or UnzipItemToFile(), UnzipClose(), and UnzipFormatMessage.
		lpUnzipOpenBuffer = (UnzipOpenBufferPtr *)GetProcAddress(unzipDll, UNZIPOPENBUFFERNAME);
		lpUnzipGetItem = (UnzipGetItemPtr *)GetProcAddress(unzipDll, UNZIPGETITEMNAME);
#ifdef UNZIPPING_TO_MEMORY
		lpUnzipItemToBuffer = (UnzipItemToBufferPtr *)GetProcAddress(unzipDll, UNZIPITEMTOBUFFERNAME);
#else
		lpUnzipItemToFile = (UnzipItemToFilePtr *)GetProcAddress(unzipDll, UNZIPITEMTOFILENAME);
#endif
		lpUnzipClose = (UnzipClosePtr *)GetProcAddress(unzipDll, UNZIPCLOSENAME);
		lpUnzipFormatMessage = (UnzipFormatMessagePtr *)GetProcAddress(unzipDll, UNZIPFORMATMESSAGENAME);

		// Load/Open the ZIP archive, which is in our EXE's resources. It is an RT_RCDATA type
		// of resource with an ID number of 1.
		if (!(result = lpUnzipOpenBuffer(&huz, 0, 1, 0)))
		{
			ZIPENTRY		ze;
			DWORD			numitems;

			// Find out how many items are in the archive.
			ze.Index = (DWORD)-1;
			if ((result = lpUnzipGetItem(huz, &ze))) goto bad2;
			numitems = ze.Index;

			// Unzip each item, using the name stored (in the zip) for that item.
			for (ze.Index = 0; ze.Index < numitems; ze.Index++)
			{
				// Get info about the next item
				if ((result = lpUnzipGetItem(huz, &ze))) goto bad2;
				{
#ifdef UNZIPPING_TO_MEMORY
					unsigned char	*buffer;

					// Allocate a memory buffer to decompress the item
					if (!(buffer = GlobalAlloc(GMEM_FIXED, ze.UncompressedSize)))
					{
						show_errmsg();
						break;
					}

					// Decompress the item into our buffer
					if ((result = lpUnzipItemToBuffer(huz, buffer, ze.UncompressedSize, &ze)))
					{
						GlobalFree(buffer);
bad2:					lpUnzipClose(huz);
						goto bad;
					}

					// Here we would do something with the contents of buffer. It contains
					// ze.UncompressedSize bytes.

					// We have no further use for the buffer, so we must free it.
					GlobalFree(buffer);
#else
					// Decompress the item to a file by the same name
					if ((result = lpUnzipItemToFile(huz, ze.Name, &ze)))
					{
bad2:					lpUnzipClose(huz);
						goto bad;
					}
#endif
				}
			}

			// Done unzipping files, so close the ZIP archive.
			lpUnzipClose(huz);
		}
		else
		{
			TCHAR	msg[100];

bad:		lpUnzipFormatMessage(result, msg, sizeof(msg));
			MessageBox(0, &msg[0], _T("Error"), MB_OK);
		}

		// Free the LiteUnzip.DLL
		FreeLibrary(unzipDll);
	}
	else
		show_errmsg();

	return(0);
}
