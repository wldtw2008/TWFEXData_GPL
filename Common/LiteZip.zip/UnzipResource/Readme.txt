This directory contains a very simple C console application
that uses the LITEUNZIP.DLL to unzip the contents of a ZIP
archive embedded as a resource in the EXE. The contents are
unzipped to memory.

In other words, simple_res.zip is embedded in UnZipResource.exe's
resources as a binary resource. It is unzipped to a memory
buffer. If you were writing an installer, you would likely
write that buffer to disk in your installation directory.