#ifdef WIN32
#include <windows.h>
#include <tchar.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
typedef void * HMODULE;
typedef char TCHAR;
#define _T(a) (a)
#endif

// Include LiteUnzip.h for unzipping a ZIP archive
#include "../LiteUnzip.h"




// Where we store the pointers to LiteUnzip.dll's functions that we call
UnzipOpenFilePtr		*lpUnzipOpenFile;
UnzipGetItemPtr			*lpUnzipGetItem;
UnzipItemToFilePtr		*lpUnzipItemToFile;
UnzipClosePtr			*lpUnzipClose;
UnzipFormatMessagePtr	*lpUnzipFormatMessage;







/************************** main() *************************
 * Program entry point.
 */

int main()
{
	HMODULE		unzipDll;
	HUNZIP		huz;
	DWORD		result;

#ifdef WIN32
	// Open the LiteUnzip.DLL. Note: If LiteUnzip.dll is not placed in a path that can be found
	// by this app, then LoadLibrary will fail. So, either copy LiteUnzip.dll to the same
	// directory as this EXE, or to some directory that Windows is set to search.
	if ((unzipDll = (HMODULE)LoadLibrary(_T("../LiteUnzip.dll"))))
	{
		// Get the addresses of 5 functions in LiteUnzip.dll -- UnzipOpenFile(), UnzipGetItem()
		// UnzipItemToFile(), UnzipClose(), and UnzipFormatMessage.
		lpUnzipOpenFile = (UnzipOpenFilePtr *)GetProcAddress(unzipDll, UNZIPOPENFILENAME);
		lpUnzipGetItem = (UnzipGetItemPtr *)GetProcAddress(unzipDll, UNZIPGETITEMNAME);
		lpUnzipItemToFile = (UnzipItemToFilePtr *)GetProcAddress(unzipDll, UNZIPITEMTOFILENAME);
		lpUnzipClose = (UnzipClosePtr *)GetProcAddress(unzipDll, UNZIPCLOSENAME);
		lpUnzipFormatMessage = (UnzipFormatMessagePtr *)GetProcAddress(unzipDll, UNZIPFORMATMESSAGENAME);
#else
	if ((unzipDll = (HMODULE)dlopen("../LiteUnzip/libliteunzip.so", RTLD_LAZY)))
	{
		// Get the addresses of 5 functions in LiteUnzip.dll -- UnzipOpenFile(), UnzipGetItem()
		// UnzipItemToFile(), UnzipClose(), and UnzipFormatMessage.
		lpUnzipOpenFile = (UnzipOpenFilePtr *)dlsym(unzipDll, UNZIPOPENFILENAME);
		lpUnzipGetItem = (UnzipGetItemPtr *)dlsym(unzipDll, UNZIPGETITEMNAME);
		lpUnzipItemToFile = (UnzipItemToFilePtr *)dlsym(unzipDll, UNZIPITEMTOFILENAME);
		lpUnzipClose = (UnzipClosePtr *)dlsym(unzipDll, UNZIPCLOSENAME);
		lpUnzipFormatMessage = (UnzipFormatMessagePtr *)dlsym(unzipDll, UNZIPFORMATMESSAGENAME);
#endif
		// Open a ZIP archive on disk named "test.zip".
		if (!(result = lpUnzipOpenFile(&huz, _T("test.zip"), 0)))
		{
			ZIPENTRY	ze;
			DWORD		numitems;

			// Find out how many items are in the archive.
			ze.Index = (DWORD)-1;
			if ((result = lpUnzipGetItem(huz, &ze))) goto bad2;
			numitems = ze.Index;

			// Unzip each item, using the name stored (in the zip) for that item.
			for (ze.Index = 0; ze.Index < numitems; ze.Index++)
			{
				if ((result = lpUnzipGetItem(huz, &ze)) || (result = lpUnzipItemToFile(huz, ze.Name, &ze)))
				{
bad2:				lpUnzipClose(huz);
					goto bad;
				}
			}

			// Done unzipping files, so close the ZIP archive.
			lpUnzipClose(huz);
		}
		else
		{
			TCHAR	msg[100];

bad:		lpUnzipFormatMessage(result, msg, sizeof(msg));
#ifdef WIN32
			MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
			printf("ERROR: %s\n", &msg[0]);
#endif
		}

		// Free the LiteUnzip.DLL
#ifdef WIN32
		FreeLibrary(unzipDll);
#else
		dlclose(unzipDll);
#endif
	}
	else
	{
#ifdef WIN32
		TCHAR buffer[160];

		buffer[0] = 0;
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 160, 0);
		MessageBox(0, &buffer[0], _T("Error"), MB_OK);
#else
		printf("ERROR: %s\n", dlerror());
#endif
	}

	return(0);
}
