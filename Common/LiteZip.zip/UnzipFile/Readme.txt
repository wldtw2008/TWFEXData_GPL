This directory contains a very simple C console application
that uses the LITEUNZIP.DLL to unzip a ZIP archive (test.zip).