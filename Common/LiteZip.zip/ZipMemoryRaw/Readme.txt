This directory contains a very simple C console application
that uses the LITEZIP.DLL to zip some memory buffer into a
ZIP archive in memory, and then write the resulting archive
to disk. The archive is zipped using one of the raw ZipAddXXX
APIs (ie, here, that's ZipAddBufferRaw), so it doesn't have
a ZIP header on it. In order to unzip later, we'll also have
to use one of LiteUnzip's raw ZipOpenXXX APIs.

For Linux, run the "makefile" with GNU's make. For Windows, open
the ZipMemoryRaw.mdp Visual Studio Workspace.