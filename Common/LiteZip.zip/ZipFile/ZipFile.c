#ifdef WIN32
#include <windows.h>
#include <tchar.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
typedef void * HMODULE;
typedef char TCHAR;
#define _T(a) (a)
#endif

// Include LiteZip.h for creating a ZIP archive
#include "../LiteZip.h"





// Where we store the pointers to LiteZip.dll's functions that we call
ZipCreateFilePtr		*lpZipCreateFile;
ZipAddFilePtr			*lpZipAddFile;
ZipClosePtr				*lpZipClose;
ZipFormatMessagePtr		*lpZipFormatMessage;





/************************** main() *************************
 * Program entry point.
 */

int main()
{
	HMODULE		zipDll;
	HZIP		hz;
	DWORD		result;

#ifdef WIN32
	// Open the LiteZip.DLL. Note: If LiteZip.dll is not placed in a path that can be found
	// by this app, then LoadLibrary will fail. So, either copy LiteZip.dll to the same
	// directory as this EXE, or to some directory that Windows is set to search.
	if ((zipDll = (HMODULE)LoadLibrary(_T("../LiteZip.dll"))))
	{
		// Get the addresses of 4 functions in LiteZip.dll -- ZipCreateFile(), ZipAddFile()
		// ZipClose(), and ZipFormatMessage.
		lpZipCreateFile = (ZipCreateFilePtr *)GetProcAddress(zipDll, ZIPCREATEFILENAME);
		lpZipAddFile = (ZipAddFilePtr *)GetProcAddress(zipDll, ZIPADDFILENAME);
		lpZipClose = (ZipClosePtr *)GetProcAddress(zipDll, ZIPCLOSENAME);
		lpZipFormatMessage = (ZipFormatMessagePtr *)GetProcAddress(zipDll, ZIPFORMATMESSAGENAME);
#else
	if ((zipDll = dlopen("../LiteZip/liblitezip.so", RTLD_LAZY)))
	{
		lpZipCreateFile = (ZipCreateFilePtr *)dlsym(zipDll, ZIPCREATEFILENAME);
		lpZipAddFile = (ZipAddFilePtr *)dlsym(zipDll, ZIPADDFILENAME);
		lpZipClose = (ZipClosePtr *)dlsym(zipDll, ZIPCLOSENAME);
		lpZipFormatMessage = (ZipFormatMessagePtr *)dlsym(zipDll, ZIPFORMATMESSAGENAME);
#endif
		// Create a ZIP archive on disk named "test.zip".
		if (!(result = lpZipCreateFile(&hz, _T("test.zip"), 0)))
		{
			// Add the file "test.jpg" to the ZIP, and give it the same name inside the ZIP.
			if ((result = lpZipAddFile(hz, _T("test.jpg"), _T("test.jpg"))) ||

				// Add the file "Readme.txt" to the ZIP, and give it the same name inside the ZIP.
				(result = lpZipAddFile(hz, _T("Readme.txt"), _T("Readme.txt"))))
			{
				lpZipClose(hz);
				goto bad;
			}

			// Here we could call ZipAddFile to add more files to the ZIP archive. We could
			// also call ZipAddBuffer to add the contents of some memory buffer as a "file"
			// inside the zip. Or, we could call ZipAddHandle to add the contents of some
			// open file or pipe.

			// Done adding files, so close the ZIP archive.
			lpZipClose(hz);
		}
		else
		{
			TCHAR	msg[100];

bad:		lpZipFormatMessage(result, msg, sizeof(msg));
#ifdef WIN32
			MessageBox(0, &msg[0], _T("Error"), MB_OK);
#else
			printf("ERROR: %s\n", &msg[0]);
#endif
		}

		// Free the LiteZip.DLL
#ifdef WIN32
		FreeLibrary(zipDll);
#else
		dlclose(zipDll);
#endif
	}
	else
	{
#ifdef WIN32
		TCHAR buffer[160];

		buffer[0] = 0;
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 160, 0);
		MessageBox(0, &buffer[0], _T("Error"), MB_OK);
#else
		printf("ERROR: %s\n", dlerror());
#endif
	}

	return(0);
}
