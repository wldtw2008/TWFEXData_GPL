//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LiteZip.rc
//

#define ZR_NOFILE     1
#define ZR_NOALLOC    2
#define ZR_WRITE      3
#define ZR_NOTFOUND   4
#define ZR_MORE       5
#define ZR_CORRUPT    6
#define ZR_READ		 7
#define ZR_NOTSUPPORTED 8
#define ZR_ARGS       9
#define ZR_NOTMMAP    10
#define ZR_MEMSIZE    11
#define ZR_FAILED     12
#define ZR_ENDED      13
#define ZR_MISSIZE    14
#define ZR_ZMODE      15
#define ZR_SEEK       16
#define ZR_NOCHANGE   17
#define ZR_FLATE      18
#define ZR_PASSWORD  19
#define ZR_ABORT  20
#define IDS_OK        21
#define IDS_UNKNOWN   22

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
