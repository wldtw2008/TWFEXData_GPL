This directory contains the source code, and Microsoft Visual
C++ (4.0 or better) project files, to create the LiteZip.DLL
file. This is the DLL that contains functions to create a ZIP
archive.

For Linux, run the "makefile" with GNU's make. For Windows, open
the LiteZip.mdp Visual Studio Workspace.

When testing the examples, it is assumed that you will copy the DLL
and .LIB files to the "Zip" root directory.